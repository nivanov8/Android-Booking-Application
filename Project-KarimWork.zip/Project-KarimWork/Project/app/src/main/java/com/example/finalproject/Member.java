package com.example.finalproject;

import android.content.Context;

public class Member extends User{

    public Member(int userId, String firstname, String lastname, String username, String password, String email){
        super(userId, firstname, lastname, username, password, email);
    }
}
