package com.example.finalproject;

import android.content.Context;

public class Instructor extends User{

    public Instructor(int userId, String firstname, String lastname, String username, String password, String email){
        super(userId, firstname, lastname, username, password, email);
    }
}
