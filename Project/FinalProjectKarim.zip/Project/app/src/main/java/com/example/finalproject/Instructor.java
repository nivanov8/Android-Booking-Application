package com.example.finalproject;

public class Instructor extends User{

    public Instructor(String firstname, String lastname, String username, String password, String email){
        super(firstname, lastname, username, password, email);
    }
}
