package com.example.finalproject;

public class Member extends User{

    public Member(String firstname, String lastname, String username, String password, String email){
        super(firstname, lastname, username, password, email);
    }
}
