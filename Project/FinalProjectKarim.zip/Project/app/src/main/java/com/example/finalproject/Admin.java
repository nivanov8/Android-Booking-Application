package com.example.finalproject;

public class Admin {


    public void createClass(){

    }
    public void removeClass(){

    }
    public void editClass(Class c){

    }
    public void removeUser(int id){

    }
}
