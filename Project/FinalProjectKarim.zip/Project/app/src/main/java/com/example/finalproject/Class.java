package com.example.finalproject;

public class Class {

    public Class (String name, String description, String difficulty, int size){

    }

}
